<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Plataforma de Casas de Festas</title>
<meta name="description" content="Site próprio, agenda sem conflito de datas e pedidos de reserva online para casas de festas.">
<?php view('head_assets'); ?>
</head>
<body>
<header class="topbar">
  <a class="brand" href="<?=e(base_url())?>" aria-label="Página inicial">P<span>•</span>F</a>
  <a class="btn outline" href="<?=e(base_url('/login.php'))?>">Área do estabelecimento</a>
</header>
<main>
  <section class="hero home-hero">
    <h1>Sua casa de festas com agenda organizada e site próprio.</h1>
    <p>Mostre o espaço, receba pedidos de reserva e controle as datas sem planilhas e sem conflito de horário.</p>
    <a class="btn primary" href="<?=e(base_url('/login.php'))?>">Acessar painel</a>
  </section>
  <section class="home-points">
    <article><h2>Site próprio</h2><p>Cada espaço ganha um endereço, galeria de fotos e as cores da sua marca.</p></article>
    <article><h2>Pedidos online</h2><p>O cliente escolhe a data num calendário e envia o pedido. Você responde pelo WhatsApp.</p></article>
    <article><h2>Agenda sem conflito</h2><p>O sistema impede confirmar duas festas na mesma data e no mesmo horário.</p></article>
  </section>
</main>
</body>
</html>
