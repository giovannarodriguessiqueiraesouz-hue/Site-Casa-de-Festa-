<?php
view('dash_header', [
    'pageTitle' => 'Administração geral', 'who' => 'Administrador geral', 'links' => [],
    'tabs' => [], 'activeTab' => '', 'flash' => $flash, 'error' => $error,
]);
?>
<div class="page-heading">
  <div><h1>Estabelecimentos</h1><p class="muted">Cadastre os espaços da plataforma e controle o acesso de cada um.</p></div>
</div>

<section class="panel">
  <h2>Novo estabelecimento</h2>
  <form method="post" class="form-grid">
    <?=csrf_field()?><input type="hidden" name="action" value="create_tenant">
    <label>Nome do espaço<input name="tenant_name" value="<?=old('tenant_name')?>" required maxlength="150"></label>
    <label>Endereço do site (slug)<input name="slug" value="<?=old('slug')?>" placeholder="espaco-dos-sonhos" maxlength="100"></label>
    <label>Nome do proprietário<input name="owner_name" value="<?=old('owner_name')?>" required maxlength="150"></label>
    <label>E-mail de acesso<input type="email" name="owner_email" value="<?=old('owner_email')?>" required maxlength="190"></label>
    <label>Senha inicial (mínimo 10 caracteres)<input type="password" name="owner_password" minlength="10" required autocomplete="new-password"></label>
    <label>Telefone / WhatsApp<input name="phone" value="<?=old('phone')?>" maxlength="30"></label>
    <label class="span-2">Descrição<textarea name="description" rows="2" maxlength="3000"><?=old('description')?></textarea></label>
    <label class="span-2">Endereço<input name="address" value="<?=old('address')?>" maxlength="255"></label>
    <div class="span-2"><button class="btn primary">Cadastrar estabelecimento</button></div>
  </form>
</section>

<section class="panel">
  <h2>Casas cadastradas</h2>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Estabelecimento</th><th>Site</th><th>Reservas</th><th>Status</th><th>Ações</th></tr></thead>
      <tbody>
      <?php foreach ($tenants as $t): ?>
        <tr>
          <td><strong><?=e($t['name'])?></strong><small><?=e($t['email'] ?? '')?></small></td>
          <td><a class="text-link" target="_blank" rel="noopener" href="<?=e(base_url('/' . $t['slug']))?>">/<?=e($t['slug'])?></a></td>
          <td><?=(int)$t['reservations_count']?><?php if ((int)$t['pending_count'] > 0): ?><small><?=(int)$t['pending_count']?> em aberto</small><?php endif; ?></td>
          <td><span class="status s-<?=e($t['status'])?>"><?=e(status_label($t['status']))?></span></td>
          <td class="actions">
            <form method="post" class="inline-form">
              <?=csrf_field()?><input type="hidden" name="action" value="toggle_tenant"><input type="hidden" name="tenant_id" value="<?=(int)$t['id']?>">
              <button class="btn outline sm" <?=$t['status'] === 'active' ? 'data-confirm="Suspender este estabelecimento? O site sai do ar e o proprietário perde o acesso."' : ''?>><?=$t['status'] === 'active' ? 'Suspender' : 'Reativar'?></button>
            </form>
            <details class="mini-form">
              <summary class="btn outline sm">Redefinir senha</summary>
              <form method="post">
                <?=csrf_field()?><input type="hidden" name="action" value="reset_owner_password"><input type="hidden" name="tenant_id" value="<?=(int)$t['id']?>">
                <label>Nova senha<input type="password" name="new_password" minlength="10" required autocomplete="new-password"></label>
                <button class="btn primary sm">Salvar senha</button>
              </form>
            </details>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$tenants): ?><tr><td colspan="5">Nenhum estabelecimento cadastrado ainda. Use o formulário acima para criar o primeiro.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php view('dash_footer'); ?>
