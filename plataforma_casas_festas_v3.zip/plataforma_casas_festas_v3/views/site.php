<?php
/** @var array $tenant @var array $gallery @var array $booked @var string $primary @var string $accent @var bool $sent @var string $formError */
$name = $tenant['name'];
$desc = trim((string)($tenant['description'] ?? ''));
$pageUrl = base_url('/' . $tenant['slug']);
$wa = whatsapp_url($tenant['phone'] ?? null, 'Olá! Vi o site de ' . $name . ' e gostaria de consultar uma data.');
$mapUrl = !empty($tenant['address']) ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($tenant['address']) : null;
$cover = $gallery[0]['image_path'] ?? null;
$metaDesc = mb_substr(strip_tags($desc !== '' ? $desc : 'Conheça ' . $name . ' e consulte datas para o seu evento.'), 0, 155);
$heroText = $desc !== '' ? mb_strimwidth($desc, 0, 220, '…') : 'Um cenário especial para transformar o seu evento em lembrança.';
$ld = ['@context' => 'https://schema.org', '@type' => 'EventVenue', 'name' => $name, 'url' => $pageUrl, 'description' => $metaDesc];
if (!empty($tenant['address'])) $ld['address'] = $tenant['address'];
if (!empty($tenant['phone'])) $ld['telephone'] = $tenant['phone'];
if ($cover) $ld['image'] = base_url('/' . $cover);
$eventTypes = ['Aniversário', 'Casamento', 'Formatura', 'Confraternização', 'Chá de bebê ou revelação', 'Evento corporativo', 'Outro'];
?><!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($name)?> | Casa de festas</title>
<meta name="description" content="<?=e($metaDesc)?>">
<link rel="canonical" href="<?=e($pageUrl)?>">
<meta property="og:type" content="website">
<meta property="og:title" content="<?=e($name)?>">
<meta property="og:description" content="<?=e($metaDesc)?>">
<meta property="og:url" content="<?=e($pageUrl)?>">
<?php if ($cover): ?><meta property="og:image" content="<?=e(base_url('/' . $cover))?>"><?php endif; ?>
<?php view('head_assets'); ?>
<style>:root{--brand:<?=$primary?>;--accent:<?=$accent?>;--on-brand:<?=contrast_text($primary)?>;--on-accent:<?=contrast_text($accent)?>}</style>
<script type="application/ld+json"><?=json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP)?></script>
</head>
<body>
<a class="skip" href="#sobre">Pular para o conteúdo</a>
<header class="site-header">
  <a class="site-logo" href="#inicio"><?=e($name)?></a>
  <nav aria-label="Seções">
    <a href="#sobre">O espaço</a>
    <?php if ($gallery): ?><a href="#galeria">Galeria</a><?php endif; ?>
    <a href="#reservar">Datas</a>
    <?php if ($wa): ?><a class="btn primary sm" href="<?=e($wa)?>" target="_blank" rel="noopener">WhatsApp</a><?php endif; ?>
  </nav>
</header>

<section id="inicio" class="venue-hero<?=$cover ? ' has-cover' : ''?>"<?php if ($cover): ?> style="background-image:linear-gradient(100deg,rgba(12,23,35,.86),rgba(12,23,35,.3)),url('<?=e(base_url('/' . $cover))?>')"<?php endif; ?>>
  <div class="venue-content">
    <h1><?=e($name)?></h1>
    <p><?=e($heroText)?></p>
    <div class="hero-actions">
      <a class="btn gold" href="#reservar">Ver datas disponíveis</a>
      <?php if ($wa): ?><a class="btn ghost-light" href="<?=e($wa)?>" target="_blank" rel="noopener">Falar no WhatsApp</a><?php endif; ?>
    </div>
  </div>
</section>

<main>
  <section id="sobre" class="section narrow">
    <h2>O espaço</h2>
    <p><?=$desc !== '' ? nl2br(e($desc)) : 'Entre em contato para conhecer o espaço e planejar o seu evento.'?></p>
    <?php if ($mapUrl): ?><p class="muted"><a class="text-link" href="<?=e($mapUrl)?>" target="_blank" rel="noopener"><?=e($tenant['address'])?></a></p><?php endif; ?>
  </section>

  <?php if ($gallery): ?>
  <section id="galeria" class="section gallery-section">
    <h2>Conheça cada detalhe</h2>
    <div class="gallery">
      <?php foreach ($gallery as $photo): ?>
        <figure>
          <img src="<?=e(base_url('/' . ltrim($photo['image_path'], '/')))?>" alt="<?=e($photo['caption'] ?: 'Foto do espaço')?>" loading="lazy">
          <?php if (!empty($photo['caption'])): ?><figcaption><?=e($photo['caption'])?></figcaption><?php endif; ?>
        </figure>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>

  <section id="reservar" class="section booking-section">
    <div class="booking-calendar">
      <h2>Escolha a data do seu evento</h2>
      <p class="muted">Toque em um dia livre para preencher o pedido ao lado. Quem responde é o próprio espaço.</p>
      <div id="availability" class="calendar" data-booked="<?=e(json_encode($booked))?>">
        <div class="cal-head">
          <button type="button" class="cal-nav" data-cal="prev" aria-label="Mês anterior">‹</button>
          <strong class="cal-title" aria-live="polite"></strong>
          <button type="button" class="cal-nav" data-cal="next" aria-label="Próximo mês">›</button>
        </div>
        <div class="cal-weekdays" aria-hidden="true"><span>D</span><span>S</span><span>T</span><span>Q</span><span>Q</span><span>S</span><span>S</span></div>
        <div class="cal-grid"></div>
        <ul class="cal-legend">
          <li><i class="dot free"></i>Livre</li>
          <li><i class="dot partial"></i>Já tem evento, veja o horário</li>
          <li><i class="dot full"></i>Ocupada</li>
        </ul>
      </div>
      <noscript><p class="muted">Ative o JavaScript para ver o calendário, ou fale direto com o espaço.</p></noscript>
    </div>

    <div class="contact-card">
      <?php if ($sent): ?>
        <div class="alert success" role="status">
          <strong>Pedido enviado.</strong> O espaço recebeu sua solicitação e vai responder pelo contato que você informou. Esse pedido ainda não garante a data.
        </div>
      <?php else: ?>
        <h3>Pedir uma data</h3>
        <?php if ($formError): ?><div class="alert error" role="alert"><?=e($formError)?></div><?php endif; ?>
        <form method="post" action="<?=e($pageUrl . '#reservar')?>" class="stack">
          <?=csrf_field()?>
          <input type="hidden" name="action" value="request_booking">
          <div class="hp" aria-hidden="true"><label>Não preencha este campo<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
          <label>Seu nome<input name="name" value="<?=old('name')?>" required maxlength="150" autocomplete="name"></label>
          <div class="row2">
            <label>WhatsApp<input name="phone" value="<?=old('phone')?>" inputmode="tel" placeholder="(64) 99999-9999" maxlength="30" autocomplete="tel"></label>
            <label>E-mail<input type="email" name="email" value="<?=old('email')?>" maxlength="190" autocomplete="email"></label>
          </div>
          <label>Data do evento<input type="date" id="event_date" name="event_date" value="<?=old('event_date')?>" min="<?=e(date('Y-m-d'))?>" required></label>
          <p id="date-note" class="field-note" role="status"></p>
          <div class="row2">
            <label>Início (opcional)<input type="time" name="start_time" value="<?=old('start_time')?>"></label>
            <label>Fim (opcional)<input type="time" name="end_time" value="<?=old('end_time')?>"></label>
          </div>
          <div class="row2">
            <label>Tipo de evento
              <select name="event_type">
                <option value="">Selecione</option>
                <?php foreach ($eventTypes as $t): ?><option<?=(($_POST['event_type'] ?? '') === $t) ? ' selected' : ''?>><?=e($t)?></option><?php endforeach; ?>
              </select>
            </label>
            <label>Convidados<input type="number" name="guest_count" min="1" max="5000" value="<?=old('guest_count')?>" required></label>
          </div>
          <label>Mensagem (opcional)<textarea name="message" rows="3" maxlength="1000"><?=old('message')?></textarea></label>
          <label class="check"><input type="checkbox" name="consent" value="1" required<?=isset($_POST['consent']) ? ' checked' : ''?>>
            <span>Concordo que <?=e($name)?> use meus dados apenas para responder a este pedido.</span></label>
          <button class="btn primary full">Enviar pedido</button>
        </form>
      <?php endif; ?>
      <div class="contact-lines">
        <?php if ($wa): ?><a class="btn outline full" href="<?=e($wa)?>" target="_blank" rel="noopener">Prefere o WhatsApp? <?=e($tenant['phone'])?></a><?php endif; ?>
        <?php if (!empty($tenant['email'])): ?><p class="muted"><a class="text-link" href="mailto:<?=e($tenant['email'])?>"><?=e($tenant['email'])?></a></p><?php endif; ?>
      </div>
    </div>
  </section>
</main>
<footer class="footer">© <?=date('Y')?> <?=e($name)?>. Todos os direitos reservados.</footer>
</body>
</html>
