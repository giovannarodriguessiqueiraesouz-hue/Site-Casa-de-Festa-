<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>Página não encontrada</title>
<?php view('head_assets'); ?>
</head>
<body class="auth-bg">
<main class="auth-card">
  <h1>Espaço não encontrado</h1>
  <p class="muted">O endereço digitado não existe ou o espaço está temporariamente indisponível.</p>
  <a class="btn primary full" href="<?=e(base_url())?>">Ir para o início</a>
</main>
</body>
</html>
