<?php
/** @var array $u @var array $tenant @var string $error @var string $activeTab @var array $stats @var array $nextEvents
 *  @var array $toAnswer @var array $reservations @var array $customers @var array $photos
 *  @var string $fStatus @var string $fWhen @var string $fQ @var ?array $flash */
$tabs = [
    'visao-geral' => ['label' => 'Visão geral'],
    'reservas'    => ['label' => 'Reservas', 'badge' => $stats['pending']],
    'clientes'    => ['label' => 'Clientes'],
    'financeiro'  => ['label' => 'Financeiro'],
    'galeria'     => ['label' => 'Galeria'],
    'meu-site'    => ['label' => 'Meu site'],
];
view('dash_header', [
    'pageTitle' => 'Painel | ' . $tenant['name'], 'who' => $tenant['name'],
    'links' => [['href' => base_url('/' . $tenant['slug']), 'label' => 'Ver meu site', 'blank' => true]],
    'tabs' => $tabs, 'activeTab' => $activeTab, 'flash' => $flash, 'error' => $error,
]);
$waLink = function (array $r): ?string {
    return whatsapp_url($r['customer_phone'] ?? null, 'Olá, ' . $r['customer_name'] . '! Recebemos seu pedido para ' . date_br($r['event_date']) . '.');
};
?>

<!-- ============ VISÃO GERAL ============ -->
<section id="visao-geral" class="tab-panel">
  <div class="page-heading"><div><h1>Olá, <?=e($u['name'])?>.</h1><p class="muted">O que precisa da sua atenção hoje.</p></div></div>

  <div class="stats">
    <article class="stat"><span>Pedidos para responder</span><strong><?=$stats['pending']?></strong></article>
    <article class="stat"><span>Próximos eventos confirmados</span><strong><?=$stats['upcoming']?></strong></article>
    <article class="stat"><span>Valor dos eventos confirmados</span><strong><?=money_br($stats['revenue'])?></strong></article>
    <article class="stat"><span>Clientes</span><strong><?=$stats['customers']?></strong></article>
  </div>

  <div class="two-col">
    <section class="panel">
      <h2>Pedidos para responder</h2>
      <?php if ($toAnswer): ?>
        <ul class="event-list">
          <?php foreach ($toAnswer as $r): $wa = $waLink($r); ?>
            <li>
              <div class="when"><strong><?=e(date('d/m', strtotime($r['event_date'])))?></strong><small><?=e(date('Y', strtotime($r['event_date'])))?></small></div>
              <div class="what"><strong><?=e($r['customer_name'])?></strong>
                <small><?=e(implode(' · ', array_filter([$r['event_type'] ?: 'Evento', $r['guest_count'] ? $r['guest_count'] . ' convidados' : '', time_range_label($r['start_time'], $r['end_time'])])))?></small></div>
              <?php if ($wa): ?><a class="btn outline sm" href="<?=e($wa)?>" target="_blank" rel="noopener">WhatsApp</a><?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
        <p><a class="text-link" href="#reservas">Ver todas as reservas</a></p>
      <?php else: ?>
        <p class="empty">Nenhum pedido esperando resposta. Divulgue o link do seu site para receber novas solicitações.</p>
      <?php endif; ?>
    </section>

    <section class="panel">
      <h2>Próximos eventos</h2>
      <?php if ($nextEvents): ?>
        <ul class="event-list">
          <?php foreach ($nextEvents as $r): ?>
            <li>
              <div class="when"><strong><?=e(date('d/m', strtotime($r['event_date'])))?></strong><small><?=e(date('Y', strtotime($r['event_date'])))?></small></div>
              <div class="what"><strong><?=e($r['customer_name'])?></strong>
                <small><?=e($r['event_type'] ?: 'Evento')?> · <?=e(time_range_label($r['start_time'], $r['end_time']))?></small></div>
              <span class="money"><?=money_br($r['total_amount'])?></span>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p class="empty">Nenhum evento confirmado para os próximos dias.</p>
      <?php endif; ?>
    </section>
  </div>
</section>

<!-- ============ RESERVAS ============ -->
<section id="reservas" class="tab-panel">
  <div class="page-heading"><div><h1>Reservas</h1><p class="muted">Pedidos do site e reservas que você cadastrou.</p></div></div>

  <details class="panel disclosure"<?=($activeTab === 'reservas' && $error && ($_POST['action'] ?? '') === 'create_reservation') ? ' open' : ''?>>
    <summary>Nova reserva</summary>
    <form method="post" class="form-grid">
      <?=csrf_field()?><input type="hidden" name="action" value="create_reservation">
      <label>Nome do cliente<input name="customer_name" value="<?=old('customer_name')?>" required maxlength="150"></label>
      <label>Telefone / WhatsApp<input name="customer_phone" value="<?=old('customer_phone')?>" maxlength="30" inputmode="tel"></label>
      <label>E-mail<input type="email" name="customer_email" value="<?=old('customer_email')?>" maxlength="190"></label>
      <label>Data do evento<input type="date" name="event_date" value="<?=old('event_date')?>" required></label>
      <label>Horário inicial<input type="time" name="start_time" value="<?=old('start_time')?>"></label>
      <label>Horário final<input type="time" name="end_time" value="<?=old('end_time')?>"></label>
      <label>Tipo de evento<input name="event_type" value="<?=old('event_type')?>" placeholder="Aniversário, casamento..." maxlength="100"></label>
      <label>Convidados<input type="number" min="0" name="guest_count" value="<?=old('guest_count')?>"></label>
      <label>Valor combinado (R$)<input type="number" min="0" step="0.01" name="total_amount" value="<?=old('total_amount', '0')?>"></label>
      <label>Situação
        <select name="status">
          <option value="requested"<?=(($_POST['status'] ?? '') !== 'confirmed') ? ' selected' : ''?>>Solicitada (ainda não bloqueia a data)</option>
          <option value="confirmed"<?=(($_POST['status'] ?? '') === 'confirmed') ? ' selected' : ''?>>Confirmada (bloqueia a data)</option>
        </select>
      </label>
      <label class="span-2">Observações<textarea name="notes" rows="2" maxlength="2000"><?=old('notes')?></textarea></label>
      <div class="span-2"><button class="btn primary">Salvar reserva</button></div>
    </form>
  </details>

  <section class="panel">
    <form method="get" action="<?=e(base_url('/admin.php'))?>" class="filters">
      <label>Período
        <select name="when">
          <option value="upcoming"<?=$fWhen === 'upcoming' ? ' selected' : ''?>>Próximas</option>
          <option value="past"<?=$fWhen === 'past' ? ' selected' : ''?>>Passadas</option>
          <option value="all"<?=$fWhen === 'all' ? ' selected' : ''?>>Todas</option>
        </select>
      </label>
      <label>Situação
        <select name="status">
          <option value="">Todas</option>
          <?php foreach (['requested', 'confirmed', 'completed', 'cancelled'] as $s): ?>
            <option value="<?=e($s)?>"<?=$fStatus === $s ? ' selected' : ''?>><?=e(status_label($s))?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="grow">Buscar cliente<input type="search" name="q" value="<?=e($fQ)?>" placeholder="Nome, telefone ou e-mail"></label>
      <button class="btn outline">Filtrar</button>
    </form>

    <div class="table-wrap">
      <table>
        <thead><tr><th>Data</th><th>Cliente</th><th>Evento</th><th>Valor</th><th>Situação</th><th>Ações</th></tr></thead>
        <tbody>
        <?php foreach ($reservations as $r): $wa = $waLink($r); ?>
          <tr>
            <td><strong><?=e(date_br($r['event_date']))?></strong><small><?=e(time_range_label($r['start_time'], $r['end_time']))?></small></td>
            <td><?=e($r['customer_name'])?>
              <small><?php if ($wa): ?><a class="text-link" href="<?=e($wa)?>" target="_blank" rel="noopener"><?=e($r['customer_phone'])?></a><?php elseif ($r['customer_phone']): ?><?=e($r['customer_phone'])?><?php else: ?><?=e($r['customer_email'] ?? '—')?><?php endif; ?></small></td>
            <td><?=e($r['event_type'] ?: '—')?><small><?=$r['guest_count'] ? (int)$r['guest_count'] . ' convidados' : ''?><?=$r['source'] === 'site' ? ' · pelo site' : ''?></small>
              <?php if (!empty($r['notes'])): ?><small class="note" title="<?=e($r['notes'])?>"><?=e(mb_strimwidth($r['notes'], 0, 60, '…'))?></small><?php endif; ?></td>
            <td><?=$r['total_amount'] > 0 ? money_br($r['total_amount']) : '—'?></td>
            <td><span class="status s-<?=e($r['status'])?>"><?=e(status_label($r['status']))?></span></td>
            <td class="actions"><?=reservation_actions($r)?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$reservations): ?><tr><td colspan="6" class="empty">Nenhuma reserva encontrada com esses filtros.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
</section>

<!-- ============ CLIENTES ============ -->
<section id="clientes" class="tab-panel">
  <div class="page-heading"><div><h1>Clientes</h1><p class="muted">Quem já pediu ou reservou uma data no seu espaço.</p></div></div>
  <section class="panel">
    <div class="table-wrap">
      <table>
        <thead><tr><th>Cliente</th><th>Contato</th><th>Reservas</th><th>Último evento</th></tr></thead>
        <tbody>
        <?php foreach ($customers as $c): $wa = whatsapp_url($c['phone']); ?>
          <tr>
            <td><strong><?=e($c['name'])?></strong></td>
            <td><?php if ($wa): ?><a class="text-link" href="<?=e($wa)?>" target="_blank" rel="noopener"><?=e($c['phone'])?></a><?php else: ?><?=e($c['phone'] ?? '')?><?php endif; ?><small><?=e($c['email'] ?? '')?></small></td>
            <td><?=(int)$c['res_count']?></td>
            <td><?=e(date_br($c['last_event']))?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$customers): ?><tr><td colspan="4" class="empty">Os clientes aparecem aqui quando você cadastra uma reserva ou recebe um pedido pelo site.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
</section>


<!-- ============ FINANCEIRO ============ -->
<section id="financeiro" class="tab-panel">
  <div class="page-heading"><div><h1>Financeiro</h1><p class="muted">Acompanhe parcelas, recebimentos e valores em aberto das reservas.</p></div></div>
  <div class="stats">
    <article class="stat"><span>Total recebido</span><strong><?=money_br($financeSummary['received'])?></strong></article>
    <article class="stat"><span>A receber</span><strong><?=money_br($financeSummary['receivable'])?></strong></article>
    <article class="stat"><span>Em atraso</span><strong><?=money_br($financeSummary['overdue'])?></strong></article>
  </div>
  <details class="panel disclosure" open>
    <summary>Novo lançamento / parcela</summary>
    <form method="post" class="form-grid">
      <?=csrf_field()?><input type="hidden" name="action" value="create_payment">
      <label class="span-2">Reserva
        <select name="reservation_id" required>
          <option value="">Selecione uma reserva</option>
          <?php foreach ($paymentReservations as $pr): ?>
            <option value="<?=(int)$pr['id']?>"><?=e(date_br($pr['event_date']))?> · <?=e($pr['customer_name'])?> · <?=money_br($pr['total_amount'])?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Valor da parcela (R$)<input type="number" name="amount" min="0.01" max="9999999.99" step="0.01" required></label>
      <label>Vencimento<input type="date" name="due_date"></label>
      <label>Forma de pagamento
        <select name="method">
          <option value="">A definir</option><option>Pix</option><option>Dinheiro</option><option>Cartão</option>
          <option>Transferência</option><option>Boleto</option><option>Outro</option>
        </select>
      </label>
      <label>Descrição<input name="description" maxlength="255" placeholder="Ex.: sinal, 1ª parcela, saldo final"></label>
      <div class="span-2"><button class="btn primary">Cadastrar lançamento</button></div>
    </form>
  </details>
  <section class="panel">
    <h2>Lançamentos</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Vencimento</th><th>Cliente / reserva</th><th>Descrição</th><th>Valor</th><th>Situação</th><th>Ação</th></tr></thead>
        <tbody>
        <?php foreach ($payments as $p): ?>
          <tr>
            <td><?=e($p['due_date'] ? date_br($p['due_date']) : 'Sem vencimento')?></td>
            <td><strong><?=e($p['customer_name'])?></strong><small>Evento: <?=e(date_br($p['event_date']))?></small></td>
            <td><?=e($p['description'] ?: 'Parcela')?><small><?=e($p['method'] ?: 'Forma não definida')?></small></td>
            <td><?=money_br($p['amount'])?></td>
            <td><span class="status <?=$p['status']==='paid'?'s-confirmed':($p['status']==='overdue'?'s-cancelled':'s-requested')?>"><?=e(match($p['status']) {'paid'=>'Pago','overdue'=>'Em atraso','refunded'=>'Estornado',default=>'Pendente'})?></span></td>
            <td>
              <?php if (in_array($p['status'], ['pending','overdue'], true)): ?>
                <form method="post" class="inline-form"><?=csrf_field()?><input type="hidden" name="action" value="mark_payment_paid"><input type="hidden" name="payment_id" value="<?=(int)$p['id']?>"><button class="btn outline sm" data-confirm="Confirmar que este valor foi recebido?">Registrar recebimento</button></form>
              <?php elseif ($p['status']==='paid'): ?>
                <small>Recebido em <?=e($p['paid_at'] ? date('d/m/Y H:i', strtotime($p['paid_at'])) : '—')?></small>
              <?php else: ?><small>—</small><?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$payments): ?><tr><td colspan="6" class="empty">Nenhum lançamento financeiro ainda. Cadastre a primeira parcela acima.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
</section>

<!-- ============ GALERIA ============ -->
<section id="galeria" class="tab-panel">
  <div class="page-heading"><div><h1>Galeria</h1><p class="muted">A primeira foto vira a capa do seu site. Formatos JPG, PNG ou WebP, até <?=(int)((defined('UPLOAD_MAX_BYTES') ? UPLOAD_MAX_BYTES : 5242880) / 1048576)?> MB.</p></div></div>
  <section class="panel">
    <form method="post" enctype="multipart/form-data" class="upload-form">
      <?=csrf_field()?><input type="hidden" name="action" value="upload_photo">
      <label>Foto<input type="file" name="photo" accept="image/jpeg,image/png,image/webp" required></label>
      <label class="grow">Legenda (opcional)<input name="caption" maxlength="180" placeholder="Salão principal, área gourmet..."></label>
      <button class="btn primary">Enviar foto</button>
    </form>
  </section>
  <?php if ($photos): ?>
    <div class="photo-grid">
      <?php foreach ($photos as $i => $p): ?>
        <figure class="photo-card">
          <img src="<?=e(base_url('/' . $p['image_path']))?>" alt="<?=e($p['caption'] ?: 'Foto da galeria')?>" loading="lazy">
          <figcaption>
            <span><?=e($p['caption'] ?: 'Sem legenda')?></span>
            <div class="actions">
              <?php if ($i === 0): ?><span class="status s-confirmed">Capa</span><?php else: ?>
                <form method="post" class="inline-form"><?=csrf_field()?><input type="hidden" name="action" value="cover_photo"><input type="hidden" name="photo_id" value="<?=(int)$p['id']?>"><button class="btn outline sm">Usar como capa</button></form>
              <?php endif; ?>
              <form method="post" class="inline-form"><?=csrf_field()?><input type="hidden" name="action" value="delete_photo"><input type="hidden" name="photo_id" value="<?=(int)$p['id']?>"><button class="btn outline sm" data-confirm="Remover esta foto da galeria?">Remover</button></form>
            </div>
          </figcaption>
        </figure>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p class="empty panel">Ainda não há fotos. Envie as primeiras para o seu site ficar mais convincente.</p>
  <?php endif; ?>
</section>

<!-- ============ MEU SITE ============ -->
<section id="meu-site" class="tab-panel">
  <div class="page-heading"><div><h1>Meu site</h1><p class="muted">Endereço público: <a class="text-link" target="_blank" rel="noopener" href="<?=e(base_url('/' . $tenant['slug']))?>"><?=e(base_url('/' . $tenant['slug']))?></a></p></div></div>
  <section class="panel">
    <h2>Informações e cores</h2>
    <form method="post" class="form-grid">
      <?=csrf_field()?><input type="hidden" name="action" value="update_site">
      <label class="span-2">Nome do espaço<input name="name" value="<?=e($tenant['name'])?>" required maxlength="150"></label>
      <label class="span-2">Descrição<textarea name="description" rows="4" maxlength="3000"><?=e($tenant['description'])?></textarea></label>
      <label>Telefone / WhatsApp<input name="phone" value="<?=e($tenant['phone'])?>" maxlength="30" inputmode="tel"></label>
      <label>E-mail de contato<input type="email" name="email" value="<?=e($tenant['email'])?>" maxlength="190"></label>
      <label class="span-2">Endereço<input name="address" value="<?=e($tenant['address'])?>" maxlength="255"></label>
      <label>Cor principal<input type="color" name="primary_color" value="<?=e($tenant['primary_color'])?>"></label>
      <label>Cor de destaque<input type="color" name="accent_color" value="<?=e($tenant['accent_color'])?>"></label>
      <div class="span-2"><button class="btn primary">Salvar alterações</button></div>
    </form>
  </section>
  <section class="panel">
    <h2>Alterar minha senha</h2>
    <form method="post" class="form-grid">
      <?=csrf_field()?><input type="hidden" name="action" value="change_password">
      <label class="span-2">Senha atual<input type="password" name="current_password" required autocomplete="current-password"></label>
      <label>Nova senha (mínimo 10 caracteres)<input type="password" name="new_password" minlength="10" required autocomplete="new-password"></label>
      <label>Repita a nova senha<input type="password" name="confirm_password" minlength="10" required autocomplete="new-password"></label>
      <div class="span-2"><button class="btn primary">Alterar senha</button></div>
    </form>
  </section>
</section>
<?php view('dash_footer'); ?>
