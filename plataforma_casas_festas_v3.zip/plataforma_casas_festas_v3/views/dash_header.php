<?php /** @var string $pageTitle @var string $who @var array $links @var array $tabs @var string $activeTab @var ?array $flash @var string $error */ ?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title><?=e($pageTitle)?></title>
<?php view('head_assets'); ?>
</head>
<body class="dashboard-bg" data-tab="<?=e($activeTab ?? '')?>">
<a class="skip" href="#main">Pular para o conteúdo</a>
<header class="dash-top">
  <a class="brand" href="<?=e(base_url('/admin.php'))?>" aria-label="Painel">P<span>•</span>F</a>
  <div class="dash-user">
    <span class="who"><?=e($who)?></span>
    <?php foreach ($links as $l): ?><a <?=!empty($l['blank']) ? 'target="_blank" rel="noopener" ' : ''?>href="<?=e($l['href'])?>"><?=e($l['label'])?></a><?php endforeach; ?>
    <a href="<?=e(base_url('/logout.php'))?>">Sair</a>
  </div>
</header>
<?php if (!empty($tabs)): ?>
<nav class="tabs" aria-label="Seções do painel">
  <?php foreach ($tabs as $id => $t): ?>
    <a href="#<?=e($id)?>" data-tab-link="<?=e($id)?>"><?=e($t['label'])?><?php if (!empty($t['badge'])): ?><span class="badge"><?=(int)$t['badge']?></span><?php endif; ?></a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>
<main id="main" class="dash-wrap">
<?php if (!empty($flash)): ?><div class="alert <?=e($flash['type'])?>" role="status"><?=e($flash['message'])?></div><?php endif; ?>
<?php if (!empty($error)): ?><div class="alert error" role="alert"><?=e($error)?></div><?php endif; ?>
