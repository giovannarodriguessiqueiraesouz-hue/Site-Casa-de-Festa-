<?php
require_once __DIR__ . '/app/bootstrap.php';
$u = require_login();

/* =====================================================================
 * ADMINISTRADOR GERAL
 * ===================================================================== */
if ($u['role'] === 'super_admin') {
    $error = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        verify_csrf();
        $action = post_str('action', 40);

        if ($action === 'create_tenant') {
            $name = post_str('tenant_name', 150);
            $slug = slugify(post_str('slug', 100) ?: $name);
            $ownerName = post_str('owner_name', 150);
            $email = filter_var(post_str('owner_email', 190), FILTER_VALIDATE_EMAIL);
            $password = is_string($_POST['owner_password'] ?? null) ? $_POST['owner_password'] : '';
            if (!$name || !$slug || !$ownerName || !$email || strlen($password) < 10) {
                $error = 'Confira os dados. A senha inicial deve ter pelo menos 10 caracteres.';
            } elseif (is_reserved_slug($slug)) {
                $error = 'O endereço "' . $slug . '" é reservado pelo sistema. Escolha outro.';
            } elseif (db_scalar('SELECT 1 FROM tenants WHERE slug=?', [$slug])) {
                $error = 'Já existe um estabelecimento com o endereço "' . $slug . '".';
            } elseif (db_scalar('SELECT 1 FROM users WHERE email=?', [$email])) {
                $error = 'Este e-mail já tem acesso à plataforma.';
            } else {
                try {
                    db()->beginTransaction();
                    db()->prepare('INSERT INTO tenants (name,slug,description,phone,email,address) VALUES (?,?,?,?,?,?)')
                        ->execute([$name, $slug, post_str('description', 3000), post_str('phone', 30), $email, post_str('address')]);
                    $tenantId = (int)db()->lastInsertId();
                    db()->prepare("INSERT INTO users (tenant_id,name,email,password_hash,role) VALUES (?,?,?,?, 'owner')")
                        ->execute([$tenantId, $ownerName, $email, password_hash($password, PASSWORD_DEFAULT)]);
                    db()->commit();
                    flash('success', 'Estabelecimento cadastrado. O site já está em /' . $slug . '.');
                    redirect('/admin.php');
                } catch (Throwable $ex) {
                    if (db()->inTransaction()) db()->rollBack();
                    error_log((string)$ex);
                    $error = 'Não foi possível cadastrar. Tente novamente.';
                }
            }
        } elseif ($action === 'toggle_tenant') {
            db()->prepare("UPDATE tenants SET status = IF(status='active','suspended','active') WHERE id=?")
                ->execute([(int)($_POST['tenant_id'] ?? 0)]);
            flash('success', 'Status do estabelecimento atualizado.');
            redirect('/admin.php');
        } elseif ($action === 'reset_owner_password') {
            $pass = is_string($_POST['new_password'] ?? null) ? $_POST['new_password'] : '';
            if (strlen($pass) < 10) {
                flash('error', 'A nova senha deve ter pelo menos 10 caracteres.');
            } else {
                db()->prepare("UPDATE users SET password_hash=? WHERE tenant_id=? AND role='owner'")
                    ->execute([password_hash($pass, PASSWORD_DEFAULT), (int)($_POST['tenant_id'] ?? 0)]);
                flash('success', 'Senha do proprietário redefinida.');
            }
            redirect('/admin.php');
        }
    }
    $tenants = db_all("SELECT t.*,
        (SELECT COUNT(*) FROM reservations r WHERE r.tenant_id=t.id) reservations_count,
        (SELECT COUNT(*) FROM reservations r WHERE r.tenant_id=t.id AND r.status='requested') pending_count
        FROM tenants t ORDER BY t.created_at DESC");
    view('admin_super', ['u' => $u, 'tenants' => $tenants, 'error' => $error, 'flash' => get_flash()]);
    exit;
}

/* =====================================================================
 * PROPRIETÁRIO DO ESTABELECIMENTO
 * ===================================================================== */
if ($u['role'] !== 'owner' || !$u['tenant_id']) { http_response_code(403); exit('Acesso negado.'); }
$stmt = db()->prepare("SELECT * FROM tenants WHERE id=? AND status='active'");
$stmt->execute([$u['tenant_id']]);
$tenant = $stmt->fetch();
if (!$tenant) { http_response_code(403); exit('Estabelecimento indisponível.'); }
tenant_user_guard($tenant);
$tid = (int)$tenant['id'];
$today = date('Y-m-d');
$error = '';
$activeTab = 'visao-geral';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post_str('action', 40);

    /* --- Nova reserva --- */
    if ($action === 'create_reservation') {
        $activeTab = 'reservas';
        $cname = post_str('customer_name', 150);
        $date = post_str('event_date', 10);
        $start = post_str('start_time', 5);
        $end = post_str('end_time', 5);
        $amount = (float)($_POST['total_amount'] ?? 0);
        $status = post_str('status', 20) === 'confirmed' ? 'confirmed' : 'requested';
        $cemail = post_str('customer_email', 190);
        if ($cname === '') {
            $error = 'Informe o nome do cliente.';
        } elseif ($cemail !== '' && !filter_var($cemail, FILTER_VALIDATE_EMAIL)) {
            $error = 'O e-mail do cliente não parece válido.';
        } elseif ($amount < 0 || $amount > 9999999.99) {
            $error = 'Informe um valor entre R$ 0,00 e R$ 9.999.999,99.';
        } elseif (($slotError = validate_event_slot($date, $start, $end, true)) !== null) {
            $error = $slotError;
        } else {
            try {
                db()->beginTransaction();
                lock_tenant($tid);
                if ($status === 'confirmed' && reservation_conflict($tid, $date, $start ?: null, $end ?: null)) {
                    db()->rollBack();
                    $error = 'Já existe uma reserva confirmada que ocupa essa data e horário. Escolha outro horário ou salve como solicitada.';
                } else {
                    $cid = find_or_create_customer($tid, $cname, $cemail, post_str('customer_phone', 30));
                    insert_reservation($tid, $cid, [
                        'event_date' => $date, 'start_time' => $start, 'end_time' => $end,
                        'event_type' => post_str('event_type', 100), 'guest_count' => max(0, (int)($_POST['guest_count'] ?? 0)),
                        'total_amount' => $amount, 'status' => $status, 'notes' => post_str('notes', 2000), 'source' => 'admin',
                    ]);
                    db()->commit();
                    flash('success', 'Reserva salva.');
                    redirect('/admin.php#reservas');
                }
            } catch (Throwable $ex) {
                if (db()->inTransaction()) db()->rollBack();
                error_log((string)$ex);
                $error = 'Não foi possível salvar a reserva. Confira os dados.';
            }
        }
    }

    /* --- Mudar status (confirmar, recusar, concluir, reabrir) --- */
    elseif ($action === 'set_status') {
        $newStatus = post_str('status', 20);
        $stmt = db()->prepare('SELECT * FROM reservations WHERE id=? AND tenant_id=?');
        $stmt->execute([(int)($_POST['reservation_id'] ?? 0), $tid]);
        $res = $stmt->fetch();
        if (!$res || !in_array($newStatus, ['requested', 'confirmed', 'cancelled', 'completed'], true)) {
            flash('error', 'Reserva não encontrada.');
        } else {
            db()->beginTransaction();
            lock_tenant($tid);
            if ($newStatus === 'confirmed' && reservation_conflict($tid, $res['event_date'], $res['start_time'], $res['end_time'], (int)$res['id'])) {
                db()->rollBack();
                flash('error', 'Não foi possível confirmar: já existe outra reserva confirmada nessa data e horário.');
            } else {
                db()->prepare('UPDATE reservations SET status=? WHERE id=? AND tenant_id=?')->execute([$newStatus, (int)$res['id'], $tid]);
                db()->commit();
                flash('success', 'Reserva atualizada: ' . mb_strtolower(status_label($newStatus)) . '.');
            }
        }
        redirect('/admin.php#reservas');
    }

    /* --- Financeiro: criar parcela/lançamento --- */
    elseif ($action === 'create_payment') {
        $activeTab = 'financeiro';
        $reservationId = (int)($_POST['reservation_id'] ?? 0);
        $amountRaw = str_replace(',', '.', (string)($_POST['amount'] ?? ''));
        $amount = is_numeric($amountRaw) ? (float)$amountRaw : 0.0;
        $dueDate = post_str('due_date', 10);
        $description = post_str('description', 255);
        $method = post_str('method', 60);
        $validMethods = ['Pix', 'Dinheiro', 'Cartão', 'Transferência', 'Boleto', 'Outro'];
        $reservation = db_all("SELECT id,total_amount,status FROM reservations WHERE id=? AND tenant_id=? LIMIT 1", [$reservationId, $tid]);
        if (!$reservation || !in_array($reservation[0]['status'], ['confirmed', 'completed'], true)) {
            $error = 'Selecione uma reserva confirmada ou concluída deste estabelecimento.';
        } elseif ($amount <= 0 || $amount > 9999999.99) {
            $error = 'Informe um valor válido maior que zero.';
        } elseif ($dueDate !== '' && !valid_date($dueDate)) {
            $error = 'Informe uma data de vencimento válida.';
        } elseif ($method !== '' && !in_array($method, $validMethods, true)) {
            $error = 'Forma de pagamento inválida.';
        } else {
            db()->prepare("INSERT INTO payments (tenant_id,reservation_id,amount,due_date,method,status,description) VALUES (?,?,?,?,?,'pending',?)")
                ->execute([$tid, $reservationId, number_format($amount, 2, '.', ''), $dueDate ?: null, $method ?: null, $description ?: null]);
            flash('success', 'Lançamento financeiro cadastrado.');
            redirect('/admin.php#financeiro');
        }
    }
    /* --- Financeiro: registrar recebimento --- */
    elseif ($action === 'mark_payment_paid') {
        $paymentId = (int)($_POST['payment_id'] ?? 0);
        $stmt = db()->prepare("UPDATE payments SET status='paid', paid_at=NOW() WHERE id=? AND tenant_id=? AND status IN ('pending','overdue')");
        $stmt->execute([$paymentId, $tid]);
        flash($stmt->rowCount() ? 'success' : 'error', $stmt->rowCount() ? 'Pagamento registrado como recebido.' : 'Lançamento não encontrado ou já finalizado.');
        redirect('/admin.php#financeiro');
    }

    /* --- Galeria --- */
    elseif ($action === 'upload_photo') {
        $activeTab = 'galeria';
        if ((int)db_scalar('SELECT COUNT(*) FROM gallery_photos WHERE tenant_id=?', [$tid]) >= GALLERY_MAX_PHOTOS) {
            $error = 'A galeria já tem ' . GALLERY_MAX_PHOTOS . ' fotos. Remova alguma para enviar outra.';
        } else {
            try {
                $path = gallery_save_upload($_FILES['photo'] ?? [], $tid);
                db()->prepare('INSERT INTO gallery_photos (tenant_id,image_path,caption) VALUES (?,?,?)')
                    ->execute([$tid, $path, post_str('caption', 180) ?: null]);
                flash('success', 'Foto adicionada à galeria.');
                redirect('/admin.php#galeria');
            } catch (RuntimeException $ex) {
                $error = $ex->getMessage();
            }
        }
    } elseif ($action === 'delete_photo') {
        $id = (int)($_POST['photo_id'] ?? 0);
        $path = db_scalar('SELECT image_path FROM gallery_photos WHERE id=? AND tenant_id=?', [$id, $tid]);
        if ($path !== false) {
            db()->prepare('DELETE FROM gallery_photos WHERE id=? AND tenant_id=?')->execute([$id, $tid]);
            gallery_delete_file((string)$path, $tid);
            flash('success', 'Foto removida.');
        }
        redirect('/admin.php#galeria');
    } elseif ($action === 'cover_photo') {
        // A primeira foto da galeria é a capa do site.
        $first = (int)db_scalar('SELECT COALESCE(MIN(sort_order),0)-1 FROM gallery_photos WHERE tenant_id=?', [$tid]);
        db()->prepare('UPDATE gallery_photos SET sort_order=? WHERE id=? AND tenant_id=?')
            ->execute([$first, (int)($_POST['photo_id'] ?? 0), $tid]);
        flash('success', 'Foto definida como capa do site.');
        redirect('/admin.php#galeria');
    }

    /* --- Dados do site --- */
    elseif ($action === 'update_site') {
        $activeTab = 'meu-site';
        $siteName = post_str('name', 150);
        $siteEmail = post_str('email', 190);
        if ($siteName === '') {
            $error = 'O nome do espaço não pode ficar em branco.';
        } elseif ($siteEmail !== '' && !filter_var($siteEmail, FILTER_VALIDATE_EMAIL)) {
            $error = 'O e-mail de contato não parece válido.';
        } else {
            db()->prepare('UPDATE tenants SET name=?,description=?,phone=?,email=?,address=?,primary_color=?,accent_color=? WHERE id=?')
                ->execute([
                    $siteName, post_str('description', 3000), post_str('phone', 30), $siteEmail, post_str('address'),
                    clean_color(post_str('primary_color', 7), '#243b53'), clean_color(post_str('accent_color', 7), '#c6a15b'), $tid,
                ]);
            flash('success', 'Informações do site atualizadas.');
            redirect('/admin.php#meu-site');
        }
    }

    /* --- Trocar a própria senha --- */
    elseif ($action === 'change_password') {
        $activeTab = 'meu-site';
        $current = is_string($_POST['current_password'] ?? null) ? $_POST['current_password'] : '';
        $new = is_string($_POST['new_password'] ?? null) ? $_POST['new_password'] : '';
        $confirm = is_string($_POST['confirm_password'] ?? null) ? $_POST['confirm_password'] : '';
        $hash = (string)db_scalar('SELECT password_hash FROM users WHERE id=?', [$u['id']]);
        if (!password_verify($current, $hash)) {
            $error = 'A senha atual não confere.';
        } elseif (strlen($new) < 10) {
            $error = 'A nova senha deve ter pelo menos 10 caracteres.';
        } elseif ($new !== $confirm) {
            $error = 'A confirmação não é igual à nova senha.';
        } else {
            db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($new, PASSWORD_DEFAULT), $u['id']]);
            session_regenerate_id(true);
            flash('success', 'Senha alterada.');
            redirect('/admin.php#meu-site');
        }
    }
}

/* ---- Dados para a tela ---- */
$stats = [
    'pending' => (int)db_scalar("SELECT COUNT(*) FROM reservations WHERE tenant_id=? AND status='requested' AND event_date>=?", [$tid, $today]),
    'upcoming' => (int)db_scalar("SELECT COUNT(*) FROM reservations WHERE tenant_id=? AND status='confirmed' AND event_date>=?", [$tid, $today]),
    'revenue' => (float)db_scalar("SELECT COALESCE(SUM(total_amount),0) FROM reservations WHERE tenant_id=? AND status='confirmed' AND event_date>=?", [$tid, $today]),
    'customers' => (int)db_scalar('SELECT COUNT(*) FROM customers WHERE tenant_id=?', [$tid]),
];
$sqlJoin = 'FROM reservations r JOIN customers c ON c.id=r.customer_id AND c.tenant_id=r.tenant_id';
$sqlCols = 'r.*, c.name customer_name, c.phone customer_phone, c.email customer_email';
$nextEvents = db_all("SELECT $sqlCols $sqlJoin WHERE r.tenant_id=? AND r.status='confirmed' AND r.event_date>=? ORDER BY r.event_date, r.start_time LIMIT 5", [$tid, $today]);
$toAnswer = db_all("SELECT $sqlCols $sqlJoin WHERE r.tenant_id=? AND r.status='requested' AND r.event_date>=? ORDER BY r.created_at LIMIT 5", [$tid, $today]);

// Filtros da lista de reservas
$fStatus = get_str('status', 20);
$fWhen = get_str('when', 10);
$fQ = get_str('q', 80);
if (!in_array($fStatus, ['requested', 'confirmed', 'cancelled', 'completed'], true)) $fStatus = '';
if (!in_array($fWhen, ['upcoming', 'past', 'all'], true)) $fWhen = 'upcoming';
if (isset($_GET['when']) || isset($_GET['q']) || isset($_GET['status'])) $activeTab = 'reservas';
$where = ['r.tenant_id=?'];
$params = [$tid];
if ($fStatus !== '') { $where[] = 'r.status=?'; $params[] = $fStatus; }
if ($fWhen === 'upcoming') { $where[] = 'r.event_date>=?'; $params[] = $today; }
if ($fWhen === 'past') { $where[] = 'r.event_date<?'; $params[] = $today; }
if ($fQ !== '') {
    $like = '%' . addcslashes($fQ, '%_\\') . '%';
    $where[] = '(c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?)';
    array_push($params, $like, $like, $like);
}
$order = $fWhen === 'upcoming' ? 'r.event_date ASC, r.start_time ASC' : 'r.event_date DESC, r.id DESC';
$reservations = db_all("SELECT $sqlCols $sqlJoin WHERE " . implode(' AND ', $where) . " ORDER BY $order LIMIT 100", $params);

$customers = db_all('SELECT c.*, COUNT(r.id) res_count, MAX(r.event_date) last_event
    FROM customers c LEFT JOIN reservations r ON r.customer_id=c.id AND r.tenant_id=c.tenant_id
    WHERE c.tenant_id=? GROUP BY c.id ORDER BY c.created_at DESC LIMIT 200', [$tid]);
$photos = db_all('SELECT id,image_path,caption FROM gallery_photos WHERE tenant_id=? ORDER BY sort_order,id DESC', [$tid]);

// Financeiro: atraso é calculado pela data de vencimento, sem depender de atualização manual.
db()->prepare("UPDATE payments SET status='overdue' WHERE tenant_id=? AND status='pending' AND due_date IS NOT NULL AND due_date<CURDATE()")
    ->execute([$tid]);
$financeSummary = db_all("SELECT
    COALESCE(SUM(CASE WHEN status='paid' THEN amount ELSE 0 END),0) received,
    COALESCE(SUM(CASE WHEN status IN ('pending','overdue') THEN amount ELSE 0 END),0) receivable,
    COALESCE(SUM(CASE WHEN status='overdue' THEN amount ELSE 0 END),0) overdue
    FROM payments WHERE tenant_id=?", [$tid])[0];
$payments = db_all("SELECT p.*, r.event_date, c.name customer_name
    FROM payments p
    JOIN reservations r ON r.id=p.reservation_id AND r.tenant_id=p.tenant_id
    JOIN customers c ON c.id=r.customer_id AND c.tenant_id=r.tenant_id
    WHERE p.tenant_id=?
    ORDER BY CASE p.status WHEN 'overdue' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END,
    p.due_date IS NULL, p.due_date ASC, p.created_at DESC LIMIT 150", [$tid]);
$paymentReservations = db_all("SELECT r.id,r.event_date,r.total_amount,c.name customer_name
    FROM reservations r JOIN customers c ON c.id=r.customer_id AND c.tenant_id=r.tenant_id
    WHERE r.tenant_id=? AND r.status IN ('confirmed','completed')
    ORDER BY r.event_date DESC LIMIT 200", [$tid]);

view('admin_owner', compact(
    'u', 'tenant', 'error', 'activeTab', 'stats', 'nextEvents', 'toAnswer', 'reservations',
    'customers', 'photos', 'fStatus', 'fWhen', 'fQ', 'financeSummary', 'payments', 'paymentReservations'
) + ['flash' => get_flash()]);
