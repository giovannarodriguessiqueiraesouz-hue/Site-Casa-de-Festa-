# Plataforma de Casas de Festas

MVP em PHP 8.1+ e MySQL 8, multi-tenant (cada casa tem site, painel e dados isolados por `tenant_id`).

## O que a plataforma faz
**Site público de cada espaço** (`/slug-do-espaco`)
- Capa e galeria com as fotos enviadas pelo proprietário, cores da marca, botão de WhatsApp e link do mapa.
- **Calendário de disponibilidade** (datas ocupadas, parciais e livres) e **formulário de pedido de reserva**
  com proteção contra robôs, limite de envios e consentimento (LGPD).
- Metadados para buscadores e compartilhamento (título, descrição, Open Graph, JSON-LD).

**Painel do proprietário** (abas: Visão geral, Reservas, Clientes, Financeiro, Galeria, Meu site)
- Pedidos para responder (com atalho de WhatsApp) e próximos eventos.
- Reservas com filtros, busca e ações: confirmar, recusar, concluir, cancelar e reabrir.
- **Sem conflito de datas:** não é possível confirmar duas reservas no mesmo dia e horário
  (considera dia inteiro e eventos que passam da meia-noite).
- Clientes reaproveitados por e-mail/telefone (sem duplicar a cada reserva).
- **Financeiro:** cadastro de parcelas vinculadas às reservas, vencimentos, forma de pagamento, registro de recebimento e resumo de valores recebidos, a receber e em atraso. O status de atraso é atualizado ao abrir o painel.
- Upload de fotos (validadas pelo conteúdo do arquivo) e escolha da capa.
- Edição do site e troca de senha.

**Administrador geral**: cadastra espaços, suspende/reativa e redefine a senha do proprietário.

**Segurança**: senhas com `password_hash`, PDO preparado, CSRF, limite de tentativas no login,
sessão com expiração por inatividade, cabeçalhos de segurança (incluindo CSP), bloqueio de acesso direto a
`app/`, `config/`, `database/`, `views/` e de execução de scripts em `uploads/`, endereços reservados (`admin`, `uploads`...).

## Instalação nova (XAMPP)
1. Copie a pasta para `C:\xampp\htdocs\` e inicie Apache e MySQL.
2. No phpMyAdmin, importe `database/schema.sql` (cria o banco `plataforma_festas`).
3. Copie `config/config.example.php` para `config/config.php` e ajuste usuário/senha do MySQL.
4. Acesse `http://localhost/plataforma_casas_festas/setup.php` e crie o administrador geral.
5. Entre em `/login.php`, cadastre um estabelecimento e abra o site em `/slug-do-estabelecimento`.

## Atualizando de uma instalação anterior
1. Faça backup do banco.
2. Selecione o banco `plataforma_festas` no phpMyAdmin e importe `database/migration_001_v2.sql`.
3. Substitua os arquivos (mantenha o seu `config/config.php` e a pasta `uploads/`).
4. Opcional: copie as novas linhas `APP_TIMEZONE` e `UPLOAD_MAX_BYTES` de `config.example.php`.

## Produção
- Use HTTPS e `APP_ENV` = `production` (esconde erros na tela e ativa HSTS).
- Remova `setup.php` depois de criar o administrador geral.
- Faça backup do banco **e** da pasta `uploads/`.
- Se o Apache usar `Alias`, descomente e ajuste o `RewriteBase` no `.htaccess`.
- Antes de uso comercial, faça revisão de segurança e adequação à LGPD (política de privacidade, prazo de retenção de dados).

## Ainda não implementado
Contratos e assinatura eletrônica, envio automático
de e-mail/WhatsApp, domínio próprio por estabelecimento e geração de PDF.

## Estrutura
- `app/`: banco, autenticação, segurança, regras de reserva/disponibilidade, uploads e helpers.
- `views/`: telas (site público, painel, cabeçalho comum).
- `public/`: CSS e JavaScript.
- `index.php`: site público e pedidos de reserva · `admin.php`: lógica do painel · `login.php`, `setup.php`.
