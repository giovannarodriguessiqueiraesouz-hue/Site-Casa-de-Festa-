// Marca a página como "com JavaScript" o quanto antes: sem JS, todas as seções do painel ficam visíveis.
document.documentElement.classList.add('js');

document.addEventListener('DOMContentLoaded', () => {
  initConfirm();
  initTabs();
  initCalendar();
});

/* Pede confirmação antes de ações destrutivas (data-confirm="mensagem"). */
function initConfirm() {
  document.querySelectorAll('[data-confirm]').forEach((el) => {
    el.addEventListener('click', (event) => {
      if (!confirm(el.dataset.confirm || 'Tem certeza?')) event.preventDefault();
    });
  });
}

/* Abas do painel, controladas pelo # da URL. */
function initTabs() {
  const panels = [...document.querySelectorAll('.tab-panel')];
  if (!panels.length) return;
  const links = [...document.querySelectorAll('[data-tab-link]')];
  const fallback = document.body.dataset.tab || panels[0].id;
  const show = () => {
    let id = location.hash.slice(1);
    if (!panels.some((p) => p.id === id)) id = fallback;
    panels.forEach((p) => p.classList.toggle('is-active', p.id === id));
    links.forEach((a) => {
      const active = a.dataset.tabLink === id;
      a.classList.toggle('is-active', active);
      if (active) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
  };
  window.addEventListener('hashchange', () => { show(); window.scrollTo(0, 0); });
  show();
}

/* Calendário de disponibilidade do site público. */
function initCalendar() {
  const root = document.getElementById('availability');
  if (!root) return;
  const booked = JSON.parse(root.dataset.booked || '{}');
  const input = document.getElementById('event_date');
  const note = document.getElementById('date-note');
  const title = root.querySelector('.cal-title');
  const grid = root.querySelector('.cal-grid');
  const prev = root.querySelector('[data-cal="prev"]');
  const next = root.querySelector('[data-cal="next"]');
  const months = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const firstMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const lastMonth = new Date(today.getFullYear(), today.getMonth() + 24, 1);
  let view = new Date(firstMonth);
  const key = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

  function updateNote() {
    if (!note || !input) return;
    const state = booked[input.value];
    if (state === 'full') note.textContent = 'Esta data já está reservada. Escolha outra no calendário.';
    else if (state === 'partial') note.textContent = 'Já existe um evento neste dia. Informe o horário abaixo para conferirmos se cabe.';
    else note.textContent = '';
  }

  function render() {
    title.textContent = `${months[view.getMonth()]} de ${view.getFullYear()}`;
    grid.replaceChildren();
    const offset = new Date(view.getFullYear(), view.getMonth(), 1).getDay();
    const days = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
    for (let i = 0; i < offset; i++) grid.appendChild(document.createElement('span'));
    for (let d = 1; d <= days; d++) {
      const date = new Date(view.getFullYear(), view.getMonth(), d);
      const k = key(date);
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'cal-day';
      btn.textContent = d;
      btn.setAttribute('aria-label', `${d} de ${months[view.getMonth()]}`);
      if (date < today) { btn.disabled = true; btn.classList.add('is-past'); }
      else if (booked[k] === 'full') { btn.disabled = true; btn.classList.add('is-full'); btn.title = 'Data ocupada'; }
      else if (booked[k] === 'partial') { btn.classList.add('is-partial'); btn.title = 'Já existe um evento neste dia'; }
      if (input && input.value === k) { btn.classList.add('is-selected'); btn.setAttribute('aria-pressed', 'true'); }
      btn.addEventListener('click', () => {
        if (!input) return;
        input.value = k;
        updateNote();
        render();
        input.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });
      grid.appendChild(btn);
    }
    prev.disabled = view <= firstMonth;
    next.disabled = view >= lastMonth;
  }

  prev.addEventListener('click', () => { view = new Date(view.getFullYear(), view.getMonth() - 1, 1); render(); });
  next.addEventListener('click', () => { view = new Date(view.getFullYear(), view.getMonth() + 1, 1); render(); });
  if (input) {
    input.addEventListener('change', () => {
      const d = new Date(`${input.value}T00:00:00`);
      if (!isNaN(d) && d >= firstMonth) view = new Date(d.getFullYear(), d.getMonth(), 1);
      updateNote();
      render();
    });
    if (input.value) {
      const d = new Date(`${input.value}T00:00:00`);
      if (!isNaN(d) && d >= firstMonth) view = new Date(d.getFullYear(), d.getMonth(), 1);
    }
  }
  updateNote();
  render();
}
