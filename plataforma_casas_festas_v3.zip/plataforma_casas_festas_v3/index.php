<?php
require_once __DIR__ . '/app/bootstrap.php';

$slug = get_str('slug', 100);
if ($slug === '') {
    view('home');
    exit;
}

$stmt = db()->prepare("SELECT * FROM tenants WHERE slug=? AND status='active' LIMIT 1");
$stmt->execute([$slug]);
$tenant = $stmt->fetch();
if (!$tenant) {
    http_response_code(404);
    view('not_found');
    exit;
}
$tid = (int)$tenant['id'];
$pageUrl = '/' . $tenant['slug'];
$formError = '';

/* ---- Pedido de reserva feito pelo cliente no site ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && post_str('action', 40) === 'request_booking') {
    verify_csrf();
    $ip = client_ip();
    $bucket = 'booking:' . $tid . ':' . $ip;

    if (post_str('website') !== '') {
        // Campo-armadilha preenchido: é um robô. Finge sucesso e não grava nada.
        redirect($pageUrl . '?enviado=1#reservar');
    }

    $name = post_str('name', 150);
    $phone = post_str('phone', 30);
    $email = post_str('email', 190);
    $date = post_str('event_date', 10);
    $start = post_str('start_time', 5);
    $end = post_str('end_time', 5);
    $type = post_str('event_type', 100);
    $guests = (int)($_POST['guest_count'] ?? 0);
    $message = post_str('message', 1000);
    $consent = isset($_POST['consent']);

    if (throttle_blocked($bucket, 5, 3600)) {
        $formError = 'Você já enviou vários pedidos. Aguarde um pouco ou fale direto com o espaço.';
    } elseif (mb_strlen($name) < 2) {
        $formError = 'Informe seu nome.';
    } elseif ($phone === '' && $email === '') {
        $formError = 'Informe um telefone/WhatsApp ou um e-mail para que o espaço possa responder.';
    } elseif ($phone !== '' && strlen(digits($phone)) < 10) {
        $formError = 'Informe o telefone com DDD.';
    } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $formError = 'O e-mail informado não parece válido.';
    } elseif ($guests < 1 || $guests > 5000) {
        $formError = 'Informe a quantidade aproximada de convidados.';
    } elseif (!$consent) {
        $formError = 'Para enviar, é preciso concordar com o uso dos seus dados para o contato.';
    } elseif (($slotError = validate_event_slot($date, $start, $end)) !== null) {
        $formError = $slotError;
    } else {
        try {
            db()->beginTransaction();
            lock_tenant($tid);
            if (reservation_conflict($tid, $date, $start ?: null, $end ?: null)) {
                db()->rollBack();
                $formError = 'Essa data já está reservada nesse horário. Escolha outra data no calendário.';
            } else {
                $cid = find_or_create_customer($tid, $name, $email, $phone, true);
                insert_reservation($tid, $cid, [
                    'event_date' => $date, 'start_time' => $start, 'end_time' => $end,
                    'event_type' => $type, 'guest_count' => $guests, 'total_amount' => 0,
                    'status' => 'requested', 'notes' => $message, 'source' => 'site',
                ]);
                db()->commit();
                throttle_record($bucket);
                redirect($pageUrl . '?enviado=1#reservar');
            }
        } catch (Throwable $ex) {
            if (db()->inTransaction()) db()->rollBack();
            error_log((string)$ex);
            $formError = 'Não foi possível enviar seu pedido agora. Tente novamente ou fale direto com o espaço.';
        }
    }
}

$gallery = db_all('SELECT image_path,caption FROM gallery_photos WHERE tenant_id=? ORDER BY sort_order,id DESC', [$tid]);
$booked = booked_days($tid, date('Y-m-d'), date('Y-m-d', strtotime('+2 years')));
$primary = clean_color($tenant['primary_color'], '#243b53');
$accent = clean_color($tenant['accent_color'], '#c6a15b');

view('site', [
    'tenant' => $tenant, 'gallery' => $gallery, 'booked' => $booked,
    'primary' => $primary, 'accent' => $accent,
    'sent' => isset($_GET['enviado']), 'formError' => $formError,
]);
