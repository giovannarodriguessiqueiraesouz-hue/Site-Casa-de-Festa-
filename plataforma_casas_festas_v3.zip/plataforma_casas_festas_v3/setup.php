<?php
require_once __DIR__ . '/app/bootstrap.php';
$count = (int)db()->query("SELECT COUNT(*) FROM users WHERE role='super_admin'")->fetchColumn();
$error = '';
if ($count > 0) {
    http_response_code(403);
    exit('O administrador geral já foi criado. Por segurança, remova setup.php do servidor.');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = post_str('name', 150);
    $email = filter_var(post_str('email', 190), FILTER_VALIDATE_EMAIL);
    $pass = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
    if (!$name || !$email || strlen($pass) < 10) {
        $error = 'Preencha os campos. A senha deve ter pelo menos 10 caracteres.';
    } else {
        $stmt = db()->prepare("INSERT INTO users (tenant_id,name,email,password_hash,role) VALUES (NULL,?,?,?,'super_admin')");
        $stmt->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT)]);
        flash('success', 'Administrador geral criado. Faça login.');
        redirect('/login.php');
    }
}
?><!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Configuração inicial</title><meta name="robots" content="noindex"><?php view('head_assets'); ?></head><body class="auth-bg"><main class="auth-card"><h1>Criar administrador geral</h1><p class="muted">Primeiro acesso: este usuário controla toda a plataforma.</p><?php if($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?><form method="post"><?=csrf_field()?><label>Nome<input name="name" required></label><label>E-mail<input type="email" name="email" required></label><label>Senha (mínimo 10 caracteres)<input type="password" name="password" minlength="10" required></label><button class="btn primary">Criar administrador</button></form></main></body></html>
