<?php
declare(strict_types=1);

const SESSION_IDLE_SECONDS = 7200; // 2 horas sem atividade encerram a sessão

function user(): ?array {
    return $_SESSION['user'] ?? null;
}
function login_user(array $row): void {
    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id' => (int)$row['id'],
        'tenant_id' => $row['tenant_id'] !== null ? (int)$row['tenant_id'] : null,
        'name' => $row['name'],
        'email' => $row['email'],
        'role' => $row['role'],
    ];
    $_SESSION['last_seen'] = time();
}
function require_login(): array {
    $u = user();
    if (!$u) redirect('/login.php');
    $expired = time() - (int)($_SESSION['last_seen'] ?? 0) > SESSION_IDLE_SECONDS;
    // O usuário pode ter sido desativado depois de entrar.
    $active = (int)db_scalar('SELECT active FROM users WHERE id=?', [$u['id']]) === 1;
    if ($expired || !$active) {
        logout_user();
        redirect('/login.php');
    }
    $_SESSION['last_seen'] = time();
    return $u;
}
function require_role(string ...$roles): array {
    $u = require_login();
    if (!in_array($u['role'], $roles, true)) {
        http_response_code(403);
        exit('Você não tem permissão para acessar esta página.');
    }
    return $u;
}
function logout_user(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}
function tenant_user_guard(array $tenant): array {
    $u = require_role('owner');
    if ((int)$u['tenant_id'] !== (int)$tenant['id']) {
        http_response_code(403);
        exit('Acesso negado: este usuário pertence a outro estabelecimento.');
    }
    return $u;
}
