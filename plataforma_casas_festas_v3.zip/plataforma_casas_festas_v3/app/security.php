<?php
declare(strict_types=1);

function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}
function verify_csrf(): void {
    $sent = $_POST['_csrf'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        http_response_code(419);
        exit('Sua sessão expirou ou o formulário é inválido. Volte e tente novamente.');
    }
}
function clean_color(string $color, string $fallback): string {
    return preg_match('/^#[0-9a-fA-F]{6}$/', $color) ? $color : $fallback;
}

/* ---- Limitador de tentativas (login, pedidos pelo site) ---- */

function throttle_hits(string $bucket, int $windowSeconds): int {
    $since = date('Y-m-d H:i:s', time() - $windowSeconds);
    return (int)db_scalar('SELECT COUNT(*) FROM rate_limits WHERE bucket=? AND created_at>=?', [$bucket, $since]);
}
function throttle_blocked(string $bucket, int $max, int $windowSeconds): bool {
    return throttle_hits($bucket, $windowSeconds) >= $max;
}
function throttle_record(string $bucket): void {
    $stmt = db()->prepare('INSERT INTO rate_limits (bucket, created_at) VALUES (?, ?)');
    $stmt->execute([mb_substr($bucket, 0, 100), date('Y-m-d H:i:s')]);
    if (random_int(1, 50) === 1) { // limpeza ocasional de registros antigos
        db()->prepare('DELETE FROM rate_limits WHERE created_at<?')
            ->execute([date('Y-m-d H:i:s', time() - 86400)]);
    }
}
