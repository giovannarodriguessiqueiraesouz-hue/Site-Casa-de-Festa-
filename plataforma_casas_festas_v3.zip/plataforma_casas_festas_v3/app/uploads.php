<?php
declare(strict_types=1);

const GALLERY_MAX_PHOTOS = 30;

/** Valida e salva uma foto da galeria. Devolve o caminho relativo ou lança RuntimeException com a mensagem para o usuário. */
function gallery_save_upload(array $file, int $tid): string {
    $err = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($err !== UPLOAD_ERR_OK) {
        throw new RuntimeException(match ($err) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'A imagem é maior que o limite permitido.',
            UPLOAD_ERR_NO_FILE => 'Selecione uma imagem para enviar.',
            default => 'Não foi possível enviar a imagem. Tente novamente.',
        });
    }
    $max = defined('UPLOAD_MAX_BYTES') ? (int)UPLOAD_MAX_BYTES : 5 * 1024 * 1024;
    if (($file['size'] ?? 0) > $max) {
        throw new RuntimeException('A imagem deve ter no máximo ' . (int)($max / 1048576) . ' MB.');
    }
    $tmp = (string)($file['tmp_name'] ?? '');
    if (!is_uploaded_file($tmp)) {
        throw new RuntimeException('Envio inválido.');
    }
    // O tipo é lido do conteúdo do arquivo, nunca do nome ou do que o navegador informa.
    $info = @getimagesize($tmp);
    $allowed = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($allowed[$info[2]])) {
        throw new RuntimeException('Use uma imagem JPG, PNG ou WebP.');
    }
    if ($info[0] > 8000 || $info[1] > 8000) {
        throw new RuntimeException('A imagem é grande demais (máximo de 8000 px de largura ou altura).');
    }
    $dir = __DIR__ . '/../uploads/' . $tid;
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        throw new RuntimeException('Não foi possível preparar a pasta de fotos no servidor.');
    }
    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$info[2]];
    if (!move_uploaded_file($tmp, $dir . '/' . $name)) {
        throw new RuntimeException('Não foi possível salvar a imagem no servidor.');
    }
    return 'uploads/' . $tid . '/' . $name;
}

/** Apaga o arquivo somente se ele estiver dentro da pasta do próprio estabelecimento. */
function gallery_delete_file(string $path, int $tid): void {
    if (strpos($path, 'uploads/' . $tid . '/') !== 0 || str_contains($path, '..')) return;
    $full = __DIR__ . '/../' . $path;
    if (is_file($full)) @unlink($full);
}
