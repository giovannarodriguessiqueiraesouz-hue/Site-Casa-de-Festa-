<?php
declare(strict_types=1);

/* ---------- Disponibilidade ----------
 * Só reservas CONFIRMADAS bloqueiam datas. Várias pessoas podem solicitar a mesma
 * data; quando o dono confirma uma, as demais deixam de poder ser confirmadas.
 * Reserva sem horário ocupa o dia inteiro. Evento que termina de madrugada
 * (ex.: 20:00 às 02:00) invade o dia seguinte, e isso também é considerado.
 */

function time_to_minutes(string $t): int {
    $parts = explode(':', $t);
    return ((int)$parts[0]) * 60 + (int)($parts[1] ?? 0);
}

/** Intervalo [início, fim) em minutos, contado a partir do dia de referência. */
function reservation_interval(string $eventDate, string $refDate, ?string $start, ?string $end): array {
    $diff = (new DateTimeImmutable($refDate))->diff(new DateTimeImmutable($eventDate));
    $offset = ((int)$diff->format('%r%a')) * 1440;
    if (!$start || !$end) return [$offset, $offset + 1440];
    $s = time_to_minutes($start);
    $e = time_to_minutes($end);
    if ($e <= $s) $e += 1440;
    return [$offset + $s, $offset + $e];
}

function reservation_conflict(int $tid, string $date, ?string $start, ?string $end, ?int $excludeId = null): bool {
    $prev = (new DateTimeImmutable($date))->modify('-1 day')->format('Y-m-d');
    $sql = "SELECT event_date,start_time,end_time FROM reservations
            WHERE tenant_id=? AND status='confirmed' AND event_date BETWEEN ? AND ?";
    $params = [$tid, $prev, $date];
    if ($excludeId !== null) {
        $sql .= ' AND id<>?';
        $params[] = $excludeId;
    }
    [$ns, $ne] = reservation_interval($date, $date, $start ?: null, $end ?: null);
    foreach (db_all($sql, $params) as $r) {
        [$os, $oe] = reservation_interval($r['event_date'], $date, $r['start_time'], $r['end_time']);
        if ($ns < $oe && $ne > $os) return true;
    }
    return false;
}

/** Datas com evento confirmado, para o calendário público: ['2026-12-05' => 'full'|'partial']. */
function booked_days(int $tid, string $from, string $to): array {
    $days = [];
    $rows = db_all("SELECT event_date,start_time,end_time FROM reservations
                    WHERE tenant_id=? AND status='confirmed' AND event_date BETWEEN ? AND ?", [$tid, $from, $to]);
    foreach ($rows as $r) {
        $full = !$r['start_time'] || !$r['end_time'];
        if ($full) $days[$r['event_date']] = 'full';
        elseif (!isset($days[$r['event_date']])) $days[$r['event_date']] = 'partial';
    }
    return $days;
}

/** Mensagem de erro para data/horário inválidos, ou null se estiver tudo certo. */
function validate_event_slot(string $date, string $start, string $end, bool $allowPast = false): ?string {
    if (!valid_date($date)) return 'Informe uma data válida para o evento.';
    if (!$allowPast && $date < date('Y-m-d')) return 'A data do evento não pode estar no passado.';
    if ($date > date('Y-m-d', strtotime('+3 years'))) return 'A data informada está distante demais.';
    if (($start === '') !== ($end === '')) return 'Informe o horário inicial e o final, ou deixe os dois em branco.';
    if ($start !== '' && (!valid_time($start) || !valid_time($end))) return 'Horário inválido.';
    if ($start !== '' && $start === $end) return 'O horário inicial e o final não podem ser iguais.';
    return null;
}

/* ---------- Clientes e reservas ---------- */

/** Serializa operações de reserva de um mesmo estabelecimento (evita confirmar duas ao mesmo tempo). */
function lock_tenant(int $tid): void {
    db_scalar('SELECT id FROM tenants WHERE id=? FOR UPDATE', [$tid]);
}

/** Reaproveita o cliente do mesmo estabelecimento (mesmo e-mail ou telefone) ou cria um novo. */
function find_or_create_customer(int $tid, string $name, string $email, string $phone, bool $consent = false): int {
    $email = $email !== '' ? strtolower($email) : null;
    $phone = $phone !== '' ? $phone : null;
    $consentAt = $consent ? date('Y-m-d H:i:s') : null;

    $conds = [];
    $params = [$tid];
    if ($email !== null) { $conds[] = 'email=?'; $params[] = $email; }
    if ($phone !== null) { $conds[] = 'phone=?'; $params[] = $phone; }
    if ($conds) {
        $id = db_scalar('SELECT id FROM customers WHERE tenant_id=? AND (' . implode(' OR ', $conds) . ') ORDER BY id LIMIT 1', $params);
        if ($id !== false) {
            db()->prepare('UPDATE customers SET email=COALESCE(email,?), phone=COALESCE(phone,?), consent_at=COALESCE(consent_at,?) WHERE id=? AND tenant_id=?')
                ->execute([$email, $phone, $consentAt, $id, $tid]);
            return (int)$id;
        }
    }
    db()->prepare('INSERT INTO customers (tenant_id,name,email,phone,consent_at) VALUES (?,?,?,?,?)')
        ->execute([$tid, $name, $email, $phone, $consentAt]);
    return (int)db()->lastInsertId();
}

/** $r: event_date, start_time, end_time, event_type, guest_count, total_amount, status, notes, source. */
function insert_reservation(int $tid, int $customerId, array $r): int {
    db()->prepare('INSERT INTO reservations
        (tenant_id,customer_id,event_date,start_time,end_time,event_type,guest_count,total_amount,status,notes,source)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([
            $tid, $customerId, $r['event_date'], $r['start_time'] ?: null, $r['end_time'] ?: null,
            $r['event_type'] !== '' ? $r['event_type'] : null, $r['guest_count'] > 0 ? $r['guest_count'] : null,
            $r['total_amount'], $r['status'], $r['notes'] !== '' ? $r['notes'] : null, $r['source'],
        ]);
    return (int)db()->lastInsertId();
}
