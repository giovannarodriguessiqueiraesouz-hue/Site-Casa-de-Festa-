<?php
declare(strict_types=1);

$configFile = __DIR__ . '/../config/config.php';
if (!file_exists($configFile)) {
    http_response_code(500);
    exit('Configure config/config.php copiando config/config.example.php.');
}
require_once $configFile;

define('IS_PROD', defined('APP_ENV') && APP_ENV === 'production');
date_default_timezone_set(defined('APP_TIMEZONE') ? APP_TIMEZONE : 'America/Sao_Paulo');
error_reporting(E_ALL);
ini_set('display_errors', IS_PROD ? '0' : '1');
ini_set('log_errors', '1');

set_exception_handler(function (Throwable $ex): void {
    error_log((string)$ex);
    if (!headers_sent()) http_response_code(500);
    echo IS_PROD
        ? 'Algo deu errado do nosso lado. Tente novamente em instantes.'
        : '<pre>' . htmlspecialchars((string)$ex, ENT_QUOTES, 'UTF-8') . '</pre>';
});

$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

// Cabeçalhos de segurança. A origem de APP_URL entra na política para que
// CSS/JS carreguem mesmo se o site for aberto por outro host (ex.: 127.0.0.1).
$appParts = parse_url(APP_URL);
$origin = isset($appParts['scheme'], $appParts['host'])
    ? $appParts['scheme'] . '://' . $appParts['host'] . (isset($appParts['port']) ? ':' . $appParts['port'] : '')
    : '';
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header("Content-Security-Policy: default-src 'self'; "
    . "script-src 'self' $origin; "
    . "style-src 'self' $origin 'unsafe-inline' https://fonts.googleapis.com; "
    . "font-src https://fonts.gstatic.com; "
    . "img-src 'self' $origin data:; "
    . "object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
if ($secure && IS_PROD) header('Strict-Transport-Security: max-age=31536000');

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'domain' => '',
        'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax'
    ]);
    session_start();
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/reservations.php';
require_once __DIR__ . '/uploads.php';
