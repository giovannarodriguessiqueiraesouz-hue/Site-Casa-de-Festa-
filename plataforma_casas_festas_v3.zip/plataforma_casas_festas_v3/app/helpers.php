<?php
declare(strict_types=1);

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function redirect(string $path): never {
    header('Location: ' . rtrim(APP_URL, '/') . $path);
    exit;
}
function base_url(string $path = ''): string {
    return rtrim(APP_URL, '/') . '/' . ltrim($path, '/');
}
/** URL de arquivo estático com versão (o navegador atualiza o cache quando o arquivo muda). */
function asset(string $path): string {
    $file = __DIR__ . '/../' . ltrim($path, '/');
    return base_url($path) . (is_file($file) ? '?v=' . filemtime($file) : '');
}
function view(string $__view, array $__vars = []): void {
    extract($__vars, EXTR_SKIP);
    require __DIR__ . '/../views/' . $__view . '.php';
}
function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}
function get_flash(): ?array {
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}
function slugify(string $value): string {
    $value = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value;
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value);
    return trim((string)$value, '-');
}
/** Nomes que conflitam com rotas ou pastas reais e não podem ser endereço de um espaço. */
function is_reserved_slug(string $slug): bool {
    return in_array($slug, [
        'admin', 'login', 'logout', 'setup', 'public', 'uploads', 'app', 'config',
        'database', 'views', 'api', 'assets', 'static', 'index', 'www',
    ], true);
}
function money_br(float|string|null $value): string {
    return 'R$ ' . number_format((float)$value, 2, ',', '.');
}
function date_br(?string $date): string {
    return $date ? date('d/m/Y', strtotime($date)) : '—';
}
function time_range_label(?string $start, ?string $end): string {
    if (!$start || !$end) return 'Dia todo';
    return substr($start, 0, 5) . ' às ' . substr($end, 0, 5);
}
function status_label(string $status): string {
    static $labels = [
        'requested' => 'Solicitada', 'confirmed' => 'Confirmada',
        'cancelled' => 'Cancelada', 'completed' => 'Concluída',
        'active' => 'Ativo', 'suspended' => 'Suspenso',
    ];
    return $labels[$status] ?? $status;
}

/** Texto de formulário (POST) já aparado e limitado em tamanho. */
function post_str(string $key, int $max = 255): string {
    $v = $_POST[$key] ?? '';
    return is_string($v) ? mb_substr(trim($v), 0, $max) : '';
}
function get_str(string $key, int $max = 100): string {
    $v = $_GET[$key] ?? '';
    return is_string($v) ? mb_substr(trim($v), 0, $max) : '';
}
/** Valor anterior de um campo, já escapado, para repopular formulários com erro. */
function old(string $key, string $default = ''): string {
    $v = $_POST[$key] ?? $default;
    return e(is_string($v) ? $v : $default);
}
function valid_date(string $d): bool {
    $dt = DateTimeImmutable::createFromFormat('Y-m-d', $d);
    return $dt !== false && $dt->format('Y-m-d') === $d;
}
function valid_time(string $t): bool {
    return (bool)preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $t);
}
function digits(?string $v): string {
    return preg_replace('/\D+/', '', (string)$v) ?? '';
}
/** Link do WhatsApp a partir de um telefone brasileiro (adiciona o 55 quando falta). */
function whatsapp_url(?string $phone, string $text = ''): ?string {
    $d = digits($phone);
    if (strlen($d) < 10) return null;
    if (strlen($d) <= 11) $d = '55' . $d;
    return 'https://wa.me/' . $d . ($text !== '' ? '?text=' . rawurlencode($text) : '');
}
function client_ip(): string {
    return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}
/** Cor de texto (branco ou grafite) com melhor contraste sobre o fundo informado. */
function contrast_text(string $hex): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) !== 6) return '#ffffff';
    $lin = [];
    foreach ([0, 2, 4] as $i) {
        $v = hexdec(substr($hex, $i, 2)) / 255;
        $lin[] = $v <= 0.03928 ? $v / 12.92 : (($v + 0.055) / 1.055) ** 2.4;
    }
    $lum = 0.2126 * $lin[0] + 0.7152 * $lin[1] + 0.0722 * $lin[2];
    return $lum > 0.22 ? '#1d2935' : '#ffffff';
}

/* ---- Pequenos blocos de HTML reutilizados no painel ---- */

function status_button(int $reservationId, string $to, string $label, string $class = 'outline', ?string $confirm = null): string {
    return '<form method="post" class="inline-form">' . csrf_field()
        . '<input type="hidden" name="action" value="set_status">'
        . '<input type="hidden" name="reservation_id" value="' . $reservationId . '">'
        . '<input type="hidden" name="status" value="' . e($to) . '">'
        . '<button class="btn ' . e($class) . ' sm"' . ($confirm ? ' data-confirm="' . e($confirm) . '"' : '') . '>' . e($label) . '</button></form>';
}
/** Botões de ação conforme a situação atual da reserva. */
function reservation_actions(array $r): string {
    $id = (int)$r['id'];
    return match ($r['status']) {
        'requested' => status_button($id, 'confirmed', 'Confirmar', 'primary')
            . status_button($id, 'cancelled', 'Recusar', 'outline', 'Recusar este pedido?'),
        'confirmed' => status_button($id, 'completed', 'Concluir', 'outline')
            . status_button($id, 'cancelled', 'Cancelar', 'outline', 'Cancelar esta reserva confirmada? A data volta a ficar livre.'),
        'cancelled' => status_button($id, 'requested', 'Reabrir', 'outline'),
        default => '',
    };
}
