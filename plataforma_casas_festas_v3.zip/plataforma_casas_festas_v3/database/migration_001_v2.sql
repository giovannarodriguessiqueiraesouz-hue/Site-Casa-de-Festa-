-- Atualização para quem JÁ instalou a versão anterior.
-- Selecione o banco "plataforma_festas" no phpMyAdmin e importe este arquivo.
-- (Instalações novas usam apenas schema.sql e NÃO precisam deste arquivo.)

ALTER TABLE customers
  ADD COLUMN consent_at DATETIME NULL AFTER notes;

ALTER TABLE reservations
  ADD COLUMN source ENUM('admin','site') NOT NULL DEFAULT 'admin' AFTER notes,
  ADD INDEX idx_reservations_status (tenant_id, status, event_date);

CREATE TABLE IF NOT EXISTS rate_limits (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bucket VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_rate_bucket (bucket, created_at)
) ENGINE=InnoDB;
