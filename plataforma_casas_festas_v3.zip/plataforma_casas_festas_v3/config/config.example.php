<?php
declare(strict_types=1);

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'plataforma_festas');
define('DB_USER', 'root');
define('DB_PASS', '');
define('APP_URL', 'http://localhost/plataforma_casas_festas');
define('APP_ENV', 'development');          // use 'production' no servidor real
define('APP_TIMEZONE', 'America/Sao_Paulo');
define('SESSION_NAME', 'plataforma_festas_session');
define('UPLOAD_MAX_BYTES', 5 * 1024 * 1024); // limite por foto da galeria
