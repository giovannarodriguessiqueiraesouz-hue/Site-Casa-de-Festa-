<?php
require_once __DIR__ . '/app/bootstrap.php';
if (user()) redirect('/admin.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = mb_strtolower(post_str('email', 190));
    $ipBucket = 'login:ip:' . client_ip();
    $mailBucket = 'login:em:' . sha1($email);
    if (throttle_blocked($ipBucket, 20, 900) || throttle_blocked($mailBucket, 5, 900)) {
        $error = 'Muitas tentativas de acesso. Aguarde 15 minutos e tente novamente.';
    } else {
        $stmt = db()->prepare("SELECT * FROM users WHERE email=? AND active=1 LIMIT 1");
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        $password = $_POST['password'] ?? '';
        if ($row && is_string($password) && password_verify($password, $row['password_hash'])) {
            if ($row['role'] === 'owner') {
                $tenantStatus = db_scalar('SELECT status FROM tenants WHERE id=?', [$row['tenant_id']]);
                if ($tenantStatus !== 'active') $row = false;
            }
            if ($row) {
                login_user($row);
                redirect('/admin.php');
            }
        }
        throttle_record($ipBucket);
        throttle_record($mailBucket);
        $error = 'E-mail ou senha inválidos, ou conta indisponível.';
    }
}
$notice = get_flash();
?><!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>Entrar | Plataforma de Casas de Festas</title>
<?php view('head_assets'); ?>
</head>
<body class="auth-bg">
<main class="auth-card">
  <a class="brand" href="<?=e(base_url())?>" aria-label="Página inicial">P<span>•</span>F</a>
  <h1>Bem-vindo de volta</h1>
  <p class="muted">Acesse o painel do seu espaço.</p>
  <?php if ($notice): ?><div class="alert <?=e($notice['type'])?>" role="status"><?=e($notice['message'])?></div><?php endif; ?>
  <?php if ($error): ?><div class="alert error" role="alert"><?=e($error)?></div><?php endif; ?>
  <form method="post">
    <?=csrf_field()?>
    <label>E-mail<input type="email" name="email" value="<?=old('email')?>" required autofocus autocomplete="username"></label>
    <label>Senha<input type="password" name="password" required autocomplete="current-password"></label>
    <button class="btn primary full">Entrar</button>
  </form>
  <a class="back-link" href="<?=e(base_url())?>">Voltar ao início</a>
</main>
</body>
</html>
